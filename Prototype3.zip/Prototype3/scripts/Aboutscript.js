function openDonationPopup() {
    document.getElementById("donationPopup").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

function closeDonationPopup() {
    document.getElementById("donationPopup").style.display = "none";
    document.getElementById("overlay").style.display = "none";
}